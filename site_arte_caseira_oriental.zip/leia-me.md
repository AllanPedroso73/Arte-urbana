# Arte Caseira

Este é um site com layout minimalista, feito para exibir desenhos orientais com traço urbano e artesanal.

## ✨ Visual

- Estilo preto e branco, com traços limpos e orientais
- Destaque para os desenhos em uma galeria central
- Fonte manual "Shadows Into Light" para manter a estética artesanal

## 🛠 Como usar

1. Clone ou baixe este repositório.
2. Substitua as imagens `oriental1.jpg`, `oriental2.jpg` e `oriental3.jpg` pelas suas artes orientais.
3. Abra o arquivo `index.html` no navegador ou publique com GitHub Pages.

## 🚀 Publicar no GitHub Pages

1. Vá nas configurações do repositório (Settings)
2. Acesse a aba **Pages**
3. Escolha a branch `main` e a pasta `/ (root)`
4. Seu site estará disponível em:  
   `https://seu-usuario.github.io/seu-repositorio`

## 📸 Créditos

Desenhos e arte por **Arte Caseira**

---

**Feito com ♥ para artistas urbanos**
